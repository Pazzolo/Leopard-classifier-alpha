# classificador_felideos > 2024-08-05 2:22pm
https://universe.roboflow.com/felideos-sjejp/classificador_felideos

Provided by a Roboflow user
License: CC BY 4.0

