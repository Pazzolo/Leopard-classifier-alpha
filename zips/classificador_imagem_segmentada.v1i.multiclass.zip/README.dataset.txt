# classificador_imagem_segmentada > 2024-08-19 2:44pm
https://universe.roboflow.com/felideos-eaemb/classificador_imagem_segmentada

Provided by a Roboflow user
License: CC BY 4.0

