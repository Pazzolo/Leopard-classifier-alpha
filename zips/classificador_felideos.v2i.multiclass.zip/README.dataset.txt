# classificador_felideos > 2024-06-20 8:27pm
https://universe.roboflow.com/willian-colombo/classificador_felideos

Provided by a Roboflow user
License: CC BY 4.0

